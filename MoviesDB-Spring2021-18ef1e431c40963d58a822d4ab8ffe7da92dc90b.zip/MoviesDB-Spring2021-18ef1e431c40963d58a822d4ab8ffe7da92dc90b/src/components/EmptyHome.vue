<template>
  <div
    class="flex flex-col items-center justify-center min-h-screen space-x-4 text-6xl text-coolGray-300 font-extralight"
  >
    <div class="flex items-center justify-center space-x-4 animate-bounce">
      <noto:film-frames />
      <h1 class="">Hello There</h1>
      <noto:film-projector />
    </div>
  </div>
</template>
